import express from "express"
import mongoose from "mongoose"
import cors from "cors"
import helmet from "helmet"
import dotenv from "dotenv"

import layoutRoutes from "./routes/layout.js"
import authRoutes   from "./routes/auth.js"
import bioRoutes    from "./routes/bio.js"
import mediaRoutes  from "./routes/media.js"

dotenv.config()

const app = express()

app.use(express.json())
app.use(helmet())

// FIX: restrict CORS to your actual frontend domain in production
// NEXT_PUBLIC_FRONTEND_URL should be set to https://ososdiscos.com in Railway env vars
app.use(cors({
  origin: process.env.FRONTEND_URL || "http://localhost:3000",
  credentials: true,
}))

// FIX: added error handling on connect — Railway will show the error in logs
// FIX: env var unified to MONGO_URI (was MONGO_URL — now consistent with docker-compose)
mongoose
  .connect(process.env.MONGO_URI)
  .then(() => console.log("MongoDB connected"))
  .catch((err) => { console.error("MongoDB connection failed:", err); process.exit(1) })

app.use("/api/layout", layoutRoutes)
app.use("/api/auth",   authRoutes)
app.use("/api/bio",    bioRoutes)
app.use("/api/media",  mediaRoutes)

app.get("/", (req, res) => res.send("Osos Discos API running"))
app.get("/api/health", (req, res) => res.json({ status: "ok" }))

const PORT = process.env.PORT || 5000
app.listen(PORT, () => console.log(`Server running on port ${PORT}`))
