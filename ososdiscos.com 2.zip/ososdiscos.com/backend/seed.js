import mongoose from "mongoose"
import dotenv from "dotenv"
import bcrypt from "bcryptjs"

import Layout from "./models/Layout.js"
import User from "./models/User.js"

dotenv.config()

// FIX: env var unified to MONGO_URI (was MONGO_URL)
await mongoose.connect(process.env.MONGO_URI)

// FIX: sections were stored as plain strings ["hero","sound"...]
// Layout model expects objects with type + order, and all 7 sections were missing
const existingLayout = await Layout.findOne({ page: "home" })
if (!existingLayout) {
  await Layout.create({
    page: "home",
    sections: [
      { type: "hero",     order: 1 },
      { type: "sound",    order: 2 },
      { type: "movies",   order: 3 },
      { type: "pictures", order: 4 },
      { type: "events",   order: 5 },
      { type: "bio",      order: 6 },
      { type: "calendar", order: 7 },
    ],
  })
  console.log("Layout seeded")
} else {
  console.log("Layout already exists — skipped")
}

// ⚠️  IMPORTANT: change this password immediately after first login
// Run: npm run seed  — then log in and update via /admin
const admin = await User.findOne({ username: "admin" })
if (!admin) {
  const hash = await bcrypt.hash("admin123", 10)
  await User.create({ username: "admin", password: hash, role: "admin" })
  console.log("Admin user seeded — CHANGE YOUR PASSWORD after first login")
} else {
  console.log("Admin user already exists — skipped")
}

console.log("Seed completed")
process.exit()
